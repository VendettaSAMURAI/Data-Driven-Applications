"""Week 1 starter file.

Goal: split the logic from prototype.py into reusable components.
"""

from __future__ import annotations

from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = {
    "case_id",
    "source_system",
    "field_name",
    "reported_value",
    "issue_text",
    "created_at",
    "reporter_team",
}


def load_cases(path: str | Path) -> pd.DataFrame:
    """Load a CSV file and perform minimal schema validation.

    TODO: read the data with pandas, then call validate_input.
    """
    raise NotImplementedError


def validate_input(df: pd.DataFrame) -> None:
    """Check whether all required columns are present.

    TODO: if a column is missing, raise ValueError with a useful message.
    """
    raise NotImplementedError


def classify_issue(text: str, field_name: str = "", reported_value: str = "") -> dict:
    """Classify one data quality case with simple rule-based logic.

    Example return value:
    {
        "issue_type": "missing_value",
        "computed_severity": "medium",
        "requires_review": True,
    }
    """
    raise NotImplementedError


def process_cases(df: pd.DataFrame) -> pd.DataFrame:
    """Process all cases and add new classification columns.

    TODO: apply classify_issue to every row.
    """
    raise NotImplementedError


def summarize_cases(df: pd.DataFrame) -> pd.DataFrame:
    """Create a simple summary table by issue_type and severity."""
    raise NotImplementedError


def save_cases(df: pd.DataFrame, path: str | Path) -> None:
    """Save the result to a CSV file."""
    raise NotImplementedError
