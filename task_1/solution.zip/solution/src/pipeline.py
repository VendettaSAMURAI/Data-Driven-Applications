"""Week 1 solution.

A reusable data-processing component created from an analytical prototype.
"""

from __future__ import annotations

from pathlib import Path

import pandas
import pandas as pd

REQUIRED_COLUMNS = {
    "case_id",
    "source_system",
    "field_name",
    "reported_value",
    "issue_text",
    "created_at",
    "reporter_team",
}


def load_cases(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    validate_input(df)
    return df


def validate_input(df: pd.DataFrame) -> None:
    missing = REQUIRED_COLUMNS.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required column(s): {', '.join(sorted(missing))}")
    if df["case_id"].isna().any():
        raise ValueError("case_id must not be missing.")


def classify_issue(text: str, field_name: str = "", reported_value: str = "") -> dict:
    text_l = str(text).lower()
    value_l = str(reported_value).lower()

    if "missing" in text_l:
        issue_type = "missing_value"
        severity = "medium"
        review = True
    elif "negative" in text_l or "non-numeric" in text_l or value_l.startswith("-"):
        issue_type = "invalid_numeric"
        severity = "high"
        review = True
    elif "date" in text_l or "date" in field_name.lower():
        issue_type = "invalid_date"
        severity = "medium"
        review = True
    elif "duplicate" in text_l:
        issue_type = "duplicate"
        severity = "medium"
        review = True
    elif "extremely high" in text_l or "outlier" in text_l:
        issue_type = "outlier"
        severity = "high"
        review = True
    elif "format" in text_l:
        issue_type = "format_error"
        severity = "low"
        review = False
    else:
        issue_type = "unknown"
        severity = "low"
        review = True

    return {
        "issue_type": issue_type,
        "computed_severity": severity,
        "requires_review": review,
    }


def process_cases(df: pd.DataFrame) -> pd.DataFrame:
    validate_input(df)
    processed = df.copy()
    results = [
        classify_issue(row.issue_text, row.field_name, row.reported_value)
        for row in processed.itertuples(index=False)
    ]
    result_df = pd.DataFrame(results)
    return pd.concat([processed.reset_index(drop=True), result_df], axis=1)


def summarize_cases(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby(["issue_type", "computed_severity"], dropna=False)
        .size()
        .reset_index(name="case_count")
        .sort_values(["computed_severity", "case_count"], ascending=[True, False])
    )


def save_cases(df: pd.DataFrame, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)

