from __future__ import annotations
from pathlib import Path
import json
import pandas as pd

ALLOWED_SENSORS = {"temp", "pressure", "humidity"}
REQUIRED_COLUMNS = {"record_id", "event_time", "sensor", "value"}

def load_folder(folder: str | Path) -> pd.DataFrame:
    folder = Path(folder)
    frames = []
    for path in sorted(folder.glob("*.csv")):
        df = pd.read_csv(path)
        missing = REQUIRED_COLUMNS - set(df.columns)
        if missing:
            raise ValueError(f"{path.name}: missing columns {sorted(missing)}")
        df["source_file"] = path.name
        frames.append(df)
    if not frames:
        raise ValueError(f"No CSV files found in {folder}")
    return pd.concat(frames, ignore_index=True)

def validate_and_split(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    work = df.copy()
    work["_parsed_time"] = pd.to_datetime(work["event_time"], errors="coerce")
    work["_parsed_value"] = pd.to_numeric(work["value"], errors="coerce")

    reasons = []
    for _, row in work.iterrows():
        row_reasons = []
        if pd.isna(row["record_id"]) or str(row["record_id"]).strip() == "":
            row_reasons.append("missing_record_id")
        if pd.isna(row["_parsed_time"]):
            row_reasons.append("invalid_event_time")
        if row["sensor"] not in ALLOWED_SENSORS:
            row_reasons.append("unsupported_sensor")
        if pd.isna(row["_parsed_value"]):
            row_reasons.append("non_numeric_value")
        reasons.append(";".join(row_reasons))

    work["rejection_reason"] = reasons
    rejected = work[work["rejection_reason"] != ""].copy()
    valid = work[work["rejection_reason"] == ""].copy()

    if not valid.empty:
        valid["event_time"] = valid["_parsed_time"]
        valid["value"] = valid["_parsed_value"]
    valid = valid.drop(columns=["_parsed_time", "_parsed_value", "rejection_reason"], errors="ignore")
    rejected = rejected.drop(columns=["_parsed_time", "_parsed_value"], errors="ignore")
    return valid, rejected

def deduplicate_latest(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df.copy()
    result = (
        df.sort_values("event_time")
          .drop_duplicates(subset=["record_id"], keep="last")
          .sort_values("record_id")
          .reset_index(drop=True)
    )
    return result

def build_run_report(
    input_rows: int,
    valid_before_dedup: int,
    rejected_rows: int,
    final_rows: int,
) -> dict:
    return {
        "input_rows": int(input_rows),
        "valid_before_dedup": int(valid_before_dedup),
        "rejected_rows": int(rejected_rows),
        "duplicates_removed": int(valid_before_dedup - final_rows),
        "final_rows": int(final_rows),
    }

def save_outputs(
    clean: pd.DataFrame,
    rejected: pd.DataFrame,
    report: dict,
    output_folder: str | Path,
) -> None:
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    clean.to_csv(output_folder / "clean.csv", index=False)
    rejected.to_csv(output_folder / "rejected.csv", index=False)
    with open(output_folder / "run_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
